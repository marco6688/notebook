package service

import (
	"testing"
)

func TestGroupService_ListByUserId(t *testing.T) {
	/*gourps, err := GroupService.ListByUserId(ctx, 1)
	fmt.Println(gourps, err)*/
}

func TestGroupService_Get(t *testing.T) {
	/*group, err := GroupService.Get(ctx, 2)
	fmt.Println(group, err)*/

}

func TestGroupService_CreateAndAddUser(t *testing.T) {
	/*GroupService.CreateAndAddUser(ctx, "group", []int64{1, 2, 3})*/
}

func TestGroupService_AddUser(t *testing.T) {
	/*GroupService.AddUser(ctx, 2, []int64{4})*/
}

func TestGroupService_DeleteUser(t *testing.T) {
	/*GroupService.DeleteUser(ctx, 2, []int64{4})*/
}

func TestGroupService_UpdateLabel(t *testing.T) {
	/*GroupService.UpdateLabel(ctx, 2, 1, "liu")*/
}
