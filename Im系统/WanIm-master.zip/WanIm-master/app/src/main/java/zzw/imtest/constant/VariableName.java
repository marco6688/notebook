package zzw.imtest.constant;



public class VariableName {

    public static boolean DEBUG=false;

    public final static String JIGUANG_APP_KEY = "be139d53989762b510f79201";
    public final static String USERNAME = "USERNAME";
    public final static String PASSWORD = "PASSWORD";
    public final static String PHONE = "PHONE";
    public final static String EMAIL = "EMAIL";
    public final static String PW = "PW";
    public final static String CODE = "CODE";
    public final static String ACCOUNT = "ACCOUNT";
    public final static String shop_type_id = "shop_type_id";
    public final static String shop_item_id = "shop_item_id";
    public final static String shop_user_name = "shop_user_name";
    public final static String shop_user_password = "shop_user_password";
    public final static String shop_user_password_confirmation = "shop_user_password_confirmation";
    public final static String identity_number = "identity_number";
    public final static String identity_name = "identity_name";
    public final static String identity_positive_img = "identity_positive_img";
    public final static String identity_back_img = "identity_back_img";
    public final static String DATA = "DATA";
    public final static String DATA_TWO = "DATA_TWO";
    public final static String DATA_THREE = "DATA_THREE";
    public final static String DATA_FOUR = "DATA_FOUR";
    public final static String DATA_FIVE = "DATA_FIVE";
    public final static String DATA_SIX = "DATA_SIX";

    public final static String TITLE = "TITLE";
    public final static String TYPE = "TYPE";
    public final static String REDP_STATE = "REDP_STATE";
    public final static String PRODUCT = "PRODUCT";

    public final static String NEW_MESSAGE = "NEW_MESSAGE";

    public final static String APP_ID = "wxa565ac43c8c84732";
    public static String FILE_DIR = "sdcard/JChatDemo/recvFiles/";
    public static String PICTURE_DIR = "sdcard/JChatDemo/pictures/";

    public final static String IMG = "IMG";
    public final static String VIDEO = "VIDEO";

    public final static int DECIMAL_NUMBER = 2;

    public final static int REQUEST_CODE_ONE = 10086;
    public final static int REQUEST_CODE_TWO = 10087;
    public final static int REQUEST_CODE_THREE = 10088;
    public final static int SCROLL_BOTTOM = 10089;
    public final static int REQUEST_CODE_FOUR = 10090;
    public final static int HIDEN_BOTTOM = 10091;
    public final static int SHOW_BOTTOM = 10092;

    public final static String RESULT = "RESULT";



    public final static int SINGLE= 0;
    public final static int GROUP= 1;


    public final static int NEW_GROUP= 0;
    public final static int PART_VISIBLE= 1;
    public final static int PART_INVISIBLE= 2;
    public final static int GROUP_ADD= 3;


    public final static String RED_PACKEGE = "RED_PACKEGE";
    public final static String ADDRESS = "ADDRESS";
    public final static String CARD = "CARD";
    public final static String INVITATION = "INVITATION";
    public final static String VIDEO_PHONE = "VIDEO_PHONE";

}
