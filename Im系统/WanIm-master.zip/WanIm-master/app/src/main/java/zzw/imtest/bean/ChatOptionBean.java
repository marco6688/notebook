package zzw.imtest.bean;

public class ChatOptionBean {
    public ChatOptionBean(int i){
        this.img=i;
    }
    public int img;
}
