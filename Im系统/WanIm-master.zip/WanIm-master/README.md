# WanIm
app预览

<img src="https://github.com/979451341/WanIm/blob/master/img/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20190917100534.jpg" width=200 /><img src="https://github.com/979451341/WanIm/blob/master/img/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20190917100553.jpg" width=200 /><img src="https://github.com/979451341/WanIm/blob/master/img/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20190917100557.jpg" width=200 /><img src="https://github.com/979451341/WanIm/blob/master/img/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20190917100601.jpg" width=200 />

<img src="https://github.com/979451341/WanIm/blob/master/img/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20190917100605.jpg" width=200 /><img src="https://github.com/979451341/WanIm/blob/master/img/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20190917100611.jpg" width=200 /><img src="https://github.com/979451341/WanIm/blob/master/img/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20190917100615.jpg" width=200 /><img src="https://github.com/979451341/WanIm/blob/master/img/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20190917100618.jpg" width=200 />

<img src="https://github.com/979451341/WanIm/blob/master/img/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20190917100625.jpg" width=200 /><img src="https://github.com/979451341/WanIm/blob/master/img/%E5%BE%AE%E4%BF%A1%E5%9B%BE%E7%89%87_20190917100628.jpg" width=200 />


实现功能

1.用户的登录注册

2.单聊，能清空聊天记录，且对于单人可以进行.语音通话，（这个部分我做的比官方demo要好得多，可以全局监听，但是没做群聊语音通话和视频通话）

3.群聊，能清空聊天记录、修改群名和修改群头像（只有群主才可以做）

4.消息类型：文字（包含系统表情）、语音、图片、视频、文件、语音通话记录（自定义消息）。

5.扫码或输入用户名搜索添加好友。

6.修改自身用户的头像和昵称、性别

 

比官方demo强的地方

1.有语音通话的实现

2.支持AndroidX

 

SDK暗坑

关于添加好友，如果你申请添加一个好友，他会到接受一个消息通知，对于好友申请不会保存在网络，需要自己缓存。

这里有安装包

https://github.com/979451341/WanIm/releases/tag/1.0

 


