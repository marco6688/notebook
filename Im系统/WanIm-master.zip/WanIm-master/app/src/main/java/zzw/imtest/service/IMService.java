package zzw.imtest.service;

import cn.jpush.android.service.JCommonService;

public class IMService extends JCommonService {
}
