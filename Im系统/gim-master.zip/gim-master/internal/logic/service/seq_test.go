package service

import (
	"testing"
)

func TestUserRequenceService_GetNext(t *testing.T) {
	/*fmt.Println(UserRequenceService.GetNext(ctx, 1))*/
}
